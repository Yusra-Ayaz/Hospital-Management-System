from collections.abc import Sequence
from decimal import Decimal
from uuid import UUID

from sqlalchemy import select
from sqlalchemy.orm import Session, selectinload

from domain.entities import Order, OrderItem, OrderStatus, Product, User
from domain.repositories import OrderRepository, ProductRepository, UserRepository
from infrastructure.models import OrderItemModel, OrderModel, ProductModel, UserModel


def _user(model: UserModel) -> User:
    return User(model.id, model.email, model.full_name, model.is_active, model.is_superuser, model.created_at, model.updated_at)


def _product(model: ProductModel) -> Product:
    return Product(model.id, model.name, model.description, model.price, model.stock, model.is_active, model.created_at, model.updated_at)


def _order(model: OrderModel) -> Order:
    items = tuple(OrderItem(i.id, i.product_id, i.quantity, i.unit_price) for i in model.items)
    return Order(model.id, model.user_id, OrderStatus(model.status), model.total_amount, items, model.created_at, model.updated_at)


class SQLAlchemyUserRepository(UserRepository):
    def __init__(self, session: Session): self._session = session
    def get(self, user_id: UUID) -> User | None:
        model = self._session.get(UserModel, user_id)
        return _user(model) if model else None
    def get_by_email(self, email: str) -> User | None:
        model = self._session.scalar(select(UserModel).where(UserModel.email == email.lower()))
        return _user(model) if model else None
    def list(self, offset: int, limit: int) -> Sequence[User]:
        return [_user(m) for m in self._session.scalars(select(UserModel).offset(offset).limit(limit)).all()]
    def create(self, *, email: str, full_name: str, password_hash: str, is_superuser: bool = False) -> User:
        model = UserModel(email=email.lower(), full_name=full_name, password_hash=password_hash, is_superuser=is_superuser)
        self._session.add(model); self._session.commit(); self._session.refresh(model); return _user(model)
    def update(self, user_id: UUID, **values: object) -> User | None:
        model = self._session.get(UserModel, user_id)
        if not model: return None
        for key, value in values.items(): setattr(model, key, value)
        self._session.commit(); self._session.refresh(model); return _user(model)
    def delete(self, user_id: UUID) -> bool:
        model = self._session.get(UserModel, user_id)
        if not model: return False
        self._session.delete(model); self._session.commit(); return True
    def password_hash_for(self, email: str) -> str | None:
        return self._session.scalar(select(UserModel.password_hash).where(UserModel.email == email.lower()))


class SQLAlchemyProductRepository(ProductRepository):
    def __init__(self, session: Session): self._session = session
    def get(self, product_id: UUID) -> Product | None:
        model = self._session.get(ProductModel, product_id); return _product(model) if model else None
    def list(self, offset: int, limit: int) -> Sequence[Product]:
        return [_product(m) for m in self._session.scalars(select(ProductModel).offset(offset).limit(limit)).all()]
    def create(self, **values: object) -> Product:
        model = ProductModel(**values); self._session.add(model); self._session.commit(); self._session.refresh(model); return _product(model)
    def update(self, product_id: UUID, **values: object) -> Product | None:
        model = self._session.get(ProductModel, product_id)
        if not model: return None
        for key, value in values.items(): setattr(model, key, value)
        self._session.commit(); self._session.refresh(model); return _product(model)
    def delete(self, product_id: UUID) -> bool:
        model = self._session.get(ProductModel, product_id)
        if not model: return False
        self._session.delete(model); self._session.commit(); return True


class SQLAlchemyOrderRepository(OrderRepository):
    def __init__(self, session: Session): self._session = session
    def _load(self, order_id: UUID) -> OrderModel | None:
        return self._session.scalar(select(OrderModel).options(selectinload(OrderModel.items)).where(OrderModel.id == order_id))
    def get(self, order_id: UUID) -> Order | None:
        model = self._load(order_id); return _order(model) if model else None
    def list_for_user(self, user_id: UUID, offset: int, limit: int) -> Sequence[Order]:
        query = select(OrderModel).options(selectinload(OrderModel.items)).where(OrderModel.user_id == user_id).offset(offset).limit(limit)
        return [_order(m) for m in self._session.scalars(query).all()]
    def create(self, user_id: UUID, items: list[dict[str, object]]) -> Order:
        total = sum((Decimal(str(i["unit_price"])) * int(i["quantity"]) for i in items), Decimal("0"))
        model = OrderModel(user_id=user_id, total_amount=total)
        model.items = [OrderItemModel(**item) for item in items]
        self._session.add(model); self._session.commit(); return _order(self._load(model.id))  # type: ignore[arg-type]
    def update_status(self, order_id: UUID, status: str) -> Order | None:
        model = self._load(order_id)
        if not model: return None
        model.status = status; self._session.commit(); return _order(self._load(order_id))  # type: ignore[arg-type]
