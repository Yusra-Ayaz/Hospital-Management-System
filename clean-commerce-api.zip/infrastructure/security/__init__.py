"""Concrete security adapters."""
