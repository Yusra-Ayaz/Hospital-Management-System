from abc import ABC, abstractmethod
from datetime import UTC, datetime, timedelta

import jwt

from core.config import get_settings
from core.exceptions import AuthenticationError


class TokenService(ABC):
    @abstractmethod
    def create_access_token(self, subject: str) -> str: ...

    @abstractmethod
    def decode_access_token(self, token: str) -> str: ...


class JWTTokenService(TokenService):
    def __init__(self) -> None:
        self._settings = get_settings()

    def create_access_token(self, subject: str) -> str:
        expires_at = datetime.now(UTC) + timedelta(minutes=self._settings.access_token_expire_minutes)
        return jwt.encode({"sub": subject, "exp": expires_at}, self._settings.jwt_secret_key, algorithm=self._settings.jwt_algorithm)

    def decode_access_token(self, token: str) -> str:
        try:
            payload = jwt.decode(token, self._settings.jwt_secret_key, algorithms=[self._settings.jwt_algorithm])
            subject = payload.get("sub")
            if not subject:
                raise AuthenticationError("Invalid authentication token")
            return str(subject)
        except jwt.PyJWTError as exc:
            raise AuthenticationError("Invalid or expired authentication token") from exc
