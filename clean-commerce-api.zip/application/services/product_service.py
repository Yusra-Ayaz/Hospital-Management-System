from collections.abc import Sequence
from uuid import UUID

from core.exceptions import NotFoundError
from domain.entities import Product
from domain.repositories import ProductRepository


class ProductService:
    def __init__(self, products: ProductRepository):
        self._products = products

    def create(self, **values: object) -> Product:
        return self._products.create(**values)

    def get(self, product_id: UUID) -> Product:
        product = self._products.get(product_id)
        if not product:
            raise NotFoundError("Product not found")
        return product

    def list(self, offset: int = 0, limit: int = 100) -> Sequence[Product]:
        return self._products.list(offset, limit)

    def update(self, product_id: UUID, **values: object) -> Product:
        product = self._products.update(product_id, **values)
        if not product:
            raise NotFoundError("Product not found")
        return product

    def delete(self, product_id: UUID) -> None:
        if not self._products.delete(product_id):
            raise NotFoundError("Product not found")
