from core.exceptions import AuthenticationError
from domain.entities import User
from domain.repositories import UserRepository
from infrastructure.security.jwt_service import TokenService
from infrastructure.security.password_service import PasswordHasher


class AuthService:
    """Authentication use case, independent from HTTP and JWT implementation."""

    def __init__(self, users: UserRepository, passwords: PasswordHasher, tokens: TokenService):
        self._users = users
        self._passwords = passwords
        self._tokens = tokens

    def login(self, email: str, password: str) -> tuple[str, User]:
        user = self._users.get_by_email(email)
        password_hash = self._users.password_hash_for(email)
        if not user or not password_hash or not user.is_active or not self._passwords.verify(password, password_hash):
            raise AuthenticationError("Incorrect email or password")
        return self._tokens.create_access_token(str(user.id)), user
