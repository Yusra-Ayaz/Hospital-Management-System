from collections.abc import Sequence
from uuid import UUID

from core.exceptions import AuthorizationError, NotFoundError, ValidationError
from domain.entities import Order, OrderStatus, User
from domain.repositories import OrderRepository, ProductRepository


class OrderService:
    """Coordinates ordering rules, including stock checks and ownership checks."""

    def __init__(self, orders: OrderRepository, products: ProductRepository):
        self._orders = orders
        self._products = products

    def create(self, user_id: UUID, items: list[dict[str, object]]) -> Order:
        if not items:
            raise ValidationError("An order must contain at least one item")
        persisted_items: list[dict[str, object]] = []
        for item in items:
            product = self._products.get(UUID(str(item["product_id"])))
            quantity = int(item["quantity"])
            if not product or not product.is_active:
                raise NotFoundError("Product not found or unavailable")
            if quantity > product.stock:
                raise ValidationError(f"Insufficient stock for product '{product.name}'")
            self._products.update(product.id, stock=product.stock - quantity)
            persisted_items.append({"product_id": product.id, "quantity": quantity, "unit_price": product.price})
        return self._orders.create(user_id, persisted_items)

    def get(self, order_id: UUID, requester: User) -> Order:
        order = self._orders.get(order_id)
        if not order:
            raise NotFoundError("Order not found")
        if order.user_id != requester.id and not requester.is_superuser:
            raise AuthorizationError("You do not have access to this order")
        return order

    def list_for_user(self, user_id: UUID, offset: int = 0, limit: int = 100) -> Sequence[Order]:
        return self._orders.list_for_user(user_id, offset, limit)

    def update_status(self, order_id: UUID, status: OrderStatus) -> Order:
        order = self._orders.update_status(order_id, status.value)
        if not order:
            raise NotFoundError("Order not found")
        return order
