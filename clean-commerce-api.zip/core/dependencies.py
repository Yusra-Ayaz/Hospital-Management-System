from uuid import UUID

from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy.orm import Session

from application.services.auth_service import AuthService
from application.services.order_service import OrderService
from application.services.product_service import ProductService
from application.services.user_service import UserService
from database.session import get_db
from infrastructure.repositories.sqlalchemy_repositories import (
    SQLAlchemyOrderRepository,
    SQLAlchemyProductRepository,
    SQLAlchemyUserRepository,
)
from infrastructure.security.jwt_service import JWTTokenService
from infrastructure.security.password_service import BcryptPasswordHasher

bearer_scheme = HTTPBearer(auto_error=False)


def get_user_service(db: Session = Depends(get_db)) -> UserService:
    return UserService(SQLAlchemyUserRepository(db), BcryptPasswordHasher())


def get_auth_service(db: Session = Depends(get_db)) -> AuthService:
    return AuthService(SQLAlchemyUserRepository(db), BcryptPasswordHasher(), JWTTokenService())


def get_product_service(db: Session = Depends(get_db)) -> ProductService:
    return ProductService(SQLAlchemyProductRepository(db))


def get_order_service(db: Session = Depends(get_db)) -> OrderService:
    return OrderService(SQLAlchemyOrderRepository(db), SQLAlchemyProductRepository(db))


def get_current_user(
    credentials: HTTPAuthorizationCredentials | None = Depends(bearer_scheme),
    db: Session = Depends(get_db),
):
    """HTTP adapter that turns a bearer token into the domain user entity."""
    if not credentials:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Authentication required", headers={"WWW-Authenticate": "Bearer"})
    from infrastructure.security.jwt_service import JWTTokenService

    try:
        user_id = UUID(JWTTokenService().decode_access_token(credentials.credentials))
    except (ValueError, Exception) as exc:
        # Application errors are intentionally translated at the delivery boundary.
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid authentication token", headers={"WWW-Authenticate": "Bearer"}) from exc
    user = SQLAlchemyUserRepository(db).get(user_id)
    if not user or not user.is_active:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Inactive or unknown user", headers={"WWW-Authenticate": "Bearer"})
    return user


def get_current_superuser(current_user=Depends(get_current_user)):
    if not current_user.is_superuser:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Administrator privileges required")
    return current_user
