# Clean Commerce API

A production-oriented FastAPI backend that demonstrates Clean Architecture, OOP, SOLID, dependency injection, repositories, and service-layer use cases. It provides JWT authentication, user/profile management, products, and orders on PostgreSQL.

## Architecture

```
presentation/    FastAPI routers and Pydantic request/response schemas
application/     Use cases and business orchestration services
domain/          Framework-independent entities and repository interfaces
infrastructure/  SQLAlchemy repository and security implementations
database/        Engine, session factory, declarative base
core/            Configuration, dependencies, logging, exception types
alembic/          Versioned PostgreSQL schema migrations
tests/            Unit tests for services and repository behavior
```

The dependency direction is `presentation → application → domain`; infrastructure implements domain interfaces and is selected by dependency injection in `core/dependencies.py`.

## OOP and SOLID

- **Encapsulation:** services keep collaborators private and domain entities expose immutable state.
- **Abstraction / DIP:** application services use abstract repository, token, and password-hashing contracts.
- **Inheritance / polymorphism:** SQLAlchemy repositories and bcrypt/JWT adapters substitute their abstract base classes.
- **SRP / separation of concerns:** routers handle HTTP, services own use cases, repositories persist data, and schemas validate input.
- **OCP, LSP, ISP:** narrow interfaces allow alternate persistence/security implementations without altering use cases.

## Quick start

1. Create PostgreSQL database `clean_commerce`.
2. Create and activate a virtual environment:

   ```bash
   python -m venv .venv
   source .venv/bin/activate  # Windows: .venv\\Scripts\\activate
   pip install -r requirements.txt
   ```

3. Copy `.env.example` to `.env`, then set `DATABASE_URL` and a long, unique `JWT_SECRET_KEY`.
4. Apply schema migrations and start the API:

   ```bash
   alembic upgrade head
   uvicorn main:app --reload
   ```

Swagger UI is available at `http://127.0.0.1:8000/docs`; OpenAPI JSON is at `/openapi.json`.

## API overview

- `POST /api/v1/auth/register`, `POST /api/v1/auth/login`
- `GET/PATCH /api/v1/profile` and `GET/PATCH /api/v1/users/me`
- Admin-only user CRUD under `/api/v1/users`
- Public product reads and admin-only product CRUD under `/api/v1/products`
- Authenticated order creation/listing/reading under `/api/v1/orders`; order status updates are admin-only.

New registrations are normal users. Promote the initial administrator directly in PostgreSQL (set `is_superuser = true`) or through an internal provisioning workflow before using admin endpoints.

## Tests

Tests isolate the service layer with in-memory repository fakes and exercise the SQLAlchemy repository mapping without needing PostgreSQL:

```bash
pytest -q
```

## Production notes

Use a secrets manager rather than committing `.env`, put the API behind TLS/reverse proxy, configure allowed CORS origins if a browser client is used, and use a managed PostgreSQL instance with backups. For multi-step stock/order writes, introduce a Unit of Work transaction when your infrastructure supports concurrent checkout traffic.
