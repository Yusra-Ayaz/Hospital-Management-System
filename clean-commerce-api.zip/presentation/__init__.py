"""FastAPI delivery layer."""
