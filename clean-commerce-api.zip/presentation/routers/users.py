from uuid import UUID

from fastapi import APIRouter, Depends, Query, status

from application.services.user_service import UserService
from core.dependencies import get_current_superuser, get_current_user, get_user_service
from domain.entities import User
from presentation.schemas import UserResponse, UserUpdate

router = APIRouter(prefix="/users", tags=["Users"])


@router.get("/me", response_model=UserResponse)
def get_me(current_user: User = Depends(get_current_user)):
    return current_user


@router.patch("/me", response_model=UserResponse)
def update_me(payload: UserUpdate, current_user: User = Depends(get_current_user), service: UserService = Depends(get_user_service)):
    values = payload.model_dump(exclude_unset=True, exclude={"is_active"})
    return service.update(current_user.id, **values)


@router.get("", response_model=list[UserResponse])
def list_users(offset: int = Query(0, ge=0), limit: int = Query(100, ge=1, le=100), _: User = Depends(get_current_superuser), service: UserService = Depends(get_user_service)):
    return service.list(offset, limit)


@router.get("/{user_id}", response_model=UserResponse)
def get_user(user_id: UUID, _: User = Depends(get_current_superuser), service: UserService = Depends(get_user_service)):
    return service.get(user_id)


@router.patch("/{user_id}", response_model=UserResponse)
def update_user(user_id: UUID, payload: UserUpdate, _: User = Depends(get_current_superuser), service: UserService = Depends(get_user_service)):
    return service.update(user_id, **payload.model_dump(exclude_unset=True))


@router.delete("/{user_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_user(user_id: UUID, _: User = Depends(get_current_superuser), service: UserService = Depends(get_user_service)):
    service.delete(user_id)
