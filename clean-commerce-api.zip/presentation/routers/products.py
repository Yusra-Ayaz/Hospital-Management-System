from uuid import UUID

from fastapi import APIRouter, Depends, Query, status

from application.services.product_service import ProductService
from core.dependencies import get_current_superuser, get_product_service
from domain.entities import User
from presentation.schemas import ProductCreate, ProductResponse, ProductUpdate

router = APIRouter(prefix="/products", tags=["Products"])


@router.get("", response_model=list[ProductResponse])
def list_products(offset: int = Query(0, ge=0), limit: int = Query(100, ge=1, le=100), service: ProductService = Depends(get_product_service)):
    return service.list(offset, limit)


@router.post("", response_model=ProductResponse, status_code=status.HTTP_201_CREATED)
def create_product(payload: ProductCreate, _: User = Depends(get_current_superuser), service: ProductService = Depends(get_product_service)):
    return service.create(**payload.model_dump())


@router.get("/{product_id}", response_model=ProductResponse)
def get_product(product_id: UUID, service: ProductService = Depends(get_product_service)):
    return service.get(product_id)


@router.patch("/{product_id}", response_model=ProductResponse)
def update_product(product_id: UUID, payload: ProductUpdate, _: User = Depends(get_current_superuser), service: ProductService = Depends(get_product_service)):
    return service.update(product_id, **payload.model_dump(exclude_unset=True))


@router.delete("/{product_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_product(product_id: UUID, _: User = Depends(get_current_superuser), service: ProductService = Depends(get_product_service)):
    service.delete(product_id)
