from fastapi import APIRouter, Depends, status

from application.services.auth_service import AuthService
from application.services.user_service import UserService
from core.dependencies import get_auth_service, get_user_service
from presentation.schemas import LoginRequest, TokenResponse, UserCreate, UserResponse

router = APIRouter(prefix="/auth", tags=["Authentication"])


@router.post("/register", response_model=UserResponse, status_code=status.HTTP_201_CREATED)
def register(payload: UserCreate, service: UserService = Depends(get_user_service)):
    return service.create(**payload.model_dump())


@router.post("/login", response_model=TokenResponse)
def login(payload: LoginRequest, service: AuthService = Depends(get_auth_service)):
    token, user = service.login(payload.email, payload.password)
    return TokenResponse(access_token=token, user=UserResponse.model_validate(user))
