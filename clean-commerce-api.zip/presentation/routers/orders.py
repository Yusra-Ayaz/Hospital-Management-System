from uuid import UUID

from fastapi import APIRouter, Depends, Query, status

from application.services.order_service import OrderService
from core.dependencies import get_current_superuser, get_current_user, get_order_service
from domain.entities import User
from presentation.schemas import OrderCreate, OrderResponse, OrderStatusUpdate

router = APIRouter(prefix="/orders", tags=["Orders"])


@router.post("", response_model=OrderResponse, status_code=status.HTTP_201_CREATED)
def create_order(payload: OrderCreate, current_user: User = Depends(get_current_user), service: OrderService = Depends(get_order_service)):
    return service.create(current_user.id, [item.model_dump() for item in payload.items])


@router.get("/me", response_model=list[OrderResponse])
def my_orders(offset: int = Query(0, ge=0), limit: int = Query(100, ge=1, le=100), current_user: User = Depends(get_current_user), service: OrderService = Depends(get_order_service)):
    return service.list_for_user(current_user.id, offset, limit)


@router.get("/{order_id}", response_model=OrderResponse)
def get_order(order_id: UUID, current_user: User = Depends(get_current_user), service: OrderService = Depends(get_order_service)):
    return service.get(order_id, current_user)


@router.patch("/{order_id}/status", response_model=OrderResponse)
def update_order_status(order_id: UUID, payload: OrderStatusUpdate, _: User = Depends(get_current_superuser), service: OrderService = Depends(get_order_service)):
    return service.update_status(order_id, payload.status)
