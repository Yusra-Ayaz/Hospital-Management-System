"""Profile endpoints keep self-service operations separate from administration."""
from fastapi import APIRouter, Depends

from application.services.user_service import UserService
from core.dependencies import get_current_user, get_user_service
from domain.entities import User
from presentation.schemas import UserResponse, UserUpdate

router = APIRouter(prefix="/profile", tags=["Profile"])


@router.get("", response_model=UserResponse)
def read_profile(current_user: User = Depends(get_current_user)):
    return current_user


@router.patch("", response_model=UserResponse)
def update_profile(payload: UserUpdate, current_user: User = Depends(get_current_user), service: UserService = Depends(get_user_service)):
    # Account activation and privilege changes are intentionally administrator-only.
    return service.update(current_user.id, **payload.model_dump(exclude_unset=True, exclude={"is_active"}))
