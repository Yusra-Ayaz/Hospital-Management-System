from abc import ABC, abstractmethod
from collections.abc import Sequence
from uuid import UUID

from domain.entities import Order, Product, User


class UserRepository(ABC):
    """Small, stable abstraction: services depend on this, not SQLAlchemy."""

    @abstractmethod
    def get(self, user_id: UUID) -> User | None: ...

    @abstractmethod
    def get_by_email(self, email: str) -> User | None: ...

    @abstractmethod
    def list(self, offset: int, limit: int) -> Sequence[User]: ...

    @abstractmethod
    def create(self, *, email: str, full_name: str, password_hash: str, is_superuser: bool = False) -> User: ...

    @abstractmethod
    def update(self, user_id: UUID, **values: object) -> User | None: ...

    @abstractmethod
    def delete(self, user_id: UUID) -> bool: ...

    @abstractmethod
    def password_hash_for(self, email: str) -> str | None: ...


class ProductRepository(ABC):
    @abstractmethod
    def get(self, product_id: UUID) -> Product | None: ...

    @abstractmethod
    def list(self, offset: int, limit: int) -> Sequence[Product]: ...

    @abstractmethod
    def create(self, **values: object) -> Product: ...

    @abstractmethod
    def update(self, product_id: UUID, **values: object) -> Product | None: ...

    @abstractmethod
    def delete(self, product_id: UUID) -> bool: ...


class OrderRepository(ABC):
    @abstractmethod
    def get(self, order_id: UUID) -> Order | None: ...

    @abstractmethod
    def list_for_user(self, user_id: UUID, offset: int, limit: int) -> Sequence[Order]: ...

    @abstractmethod
    def create(self, user_id: UUID, items: list[dict[str, object]]) -> Order: ...

    @abstractmethod
    def update_status(self, order_id: UUID, status: str) -> Order | None: ...
