from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal
from enum import StrEnum
from uuid import UUID


class OrderStatus(StrEnum):
    PENDING = "pending"
    PAID = "paid"
    CANCELLED = "cancelled"


@dataclass(frozen=True, slots=True)
class OrderItem:
    id: UUID
    product_id: UUID
    quantity: int
    unit_price: Decimal

    @property
    def subtotal(self) -> Decimal:
        return self.unit_price * self.quantity


@dataclass(frozen=True, slots=True)
class Order:
    id: UUID
    user_id: UUID
    status: OrderStatus
    total_amount: Decimal
    items: tuple[OrderItem, ...]
    created_at: datetime
    updated_at: datetime
