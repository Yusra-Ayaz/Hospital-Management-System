import logging

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse

from core.config import get_settings
from core.exceptions import ApplicationError, AuthenticationError, AuthorizationError, ConflictError, NotFoundError, ValidationError
from core.logging import configure_logging
from presentation.routers import auth, orders, products, profile, users

configure_logging()
settings = get_settings()
logger = logging.getLogger(__name__)
app = FastAPI(title=settings.app_name, version="1.0.0", description="Clean Architecture commerce API")


@app.exception_handler(ApplicationError)
async def application_error_handler(_: Request, exc: ApplicationError) -> JSONResponse:
    status_code = 400
    if isinstance(exc, NotFoundError): status_code = 404
    elif isinstance(exc, ConflictError): status_code = 409
    elif isinstance(exc, (AuthenticationError, AuthorizationError)): status_code = 401 if isinstance(exc, AuthenticationError) else 403
    elif isinstance(exc, ValidationError): status_code = 422
    return JSONResponse(status_code=status_code, content={"detail": str(exc)})


@app.exception_handler(Exception)
async def unexpected_error_handler(_: Request, exc: Exception) -> JSONResponse:
    logger.exception("Unhandled application error", exc_info=exc)
    return JSONResponse(status_code=500, content={"detail": "Internal server error"})


@app.get("/health", tags=["Health"])
def health_check() -> dict[str, str]:
    return {"status": "ok", "environment": settings.environment}


app.include_router(auth.router, prefix="/api/v1")
app.include_router(users.router, prefix="/api/v1")
app.include_router(profile.router, prefix="/api/v1")
app.include_router(products.router, prefix="/api/v1")
app.include_router(orders.router, prefix="/api/v1")
