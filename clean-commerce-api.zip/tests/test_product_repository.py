from decimal import Decimal

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from database.session import Base
from infrastructure.models import ProductModel  # noqa: F401 - loads tables into metadata
from infrastructure.repositories.sqlalchemy_repositories import SQLAlchemyProductRepository


def test_product_repository_crud_round_trip():
    engine = create_engine("sqlite+pysqlite:///:memory:")
    Base.metadata.create_all(engine)
    session = sessionmaker(bind=engine)()
    repository = SQLAlchemyProductRepository(session)

    created = repository.create(name="Stethoscope", description="Clinical", price=Decimal("25.00"), stock=3, is_active=True)
    updated = repository.update(created.id, stock=8)

    assert repository.get(created.id).name == "Stethoscope"
    assert updated.stock == 8
    assert repository.delete(created.id) is True
    assert repository.get(created.id) is None
