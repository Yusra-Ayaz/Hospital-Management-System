from datetime import UTC, datetime
from uuid import uuid4

import pytest

from application.services.user_service import UserService
from core.exceptions import ConflictError
from domain.entities import User
from domain.repositories import UserRepository
from infrastructure.security.password_service import PasswordHasher


class FakeUsers(UserRepository):
    def __init__(self): self.records: dict[str, User] = {}
    def get(self, user_id): return next((u for u in self.records.values() if u.id == user_id), None)
    def get_by_email(self, email): return self.records.get(email.lower())
    def list(self, offset, limit): return list(self.records.values())[offset:offset + limit]
    def create(self, *, email, full_name, password_hash, is_superuser=False):
        now = datetime.now(UTC); user = User(uuid4(), email.lower(), full_name, True, is_superuser, now, now)
        self.records[user.email] = user; self.password = password_hash; return user
    def update(self, user_id, **values): return self.get(user_id)
    def delete(self, user_id): return False
    def password_hash_for(self, email): return getattr(self, "password", None) if email.lower() in self.records else None


class StubHasher(PasswordHasher):
    def hash(self, password): return f"hashed:{password}"
    def verify(self, password, password_hash): return password_hash == f"hashed:{password}"


def test_user_service_hashes_password_and_normalizes_email():
    repo = FakeUsers()
    user = UserService(repo, StubHasher()).create("TEST@EXAMPLE.COM", "Test User", "password123")
    assert user.email == "test@example.com"
    assert repo.password == "hashed:password123"


def test_user_service_rejects_duplicate_email():
    repo = FakeUsers(); service = UserService(repo, StubHasher())
    service.create("test@example.com", "Test User", "password123")
    with pytest.raises(ConflictError):
        service.create("test@example.com", "Other User", "password123")
